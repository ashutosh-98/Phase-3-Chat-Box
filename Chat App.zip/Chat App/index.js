var express=require("express");
var path=require("path");
var bodyParser=require("body-parser");
var http=require("http");
var socketio=require("socket.io");
var querystring=require("querystring");
//const { response } = require("express");
var userObj=require("./utils/usersInfo");
var messageObj=require("./utils/messageManagement");

const PORT=3000;

var app=express();
const server=http.createServer(app);
var io=socketio(server);

app.use(express.static(path.join(__dirname,"public")));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:false}));

app.get("/",(request,response)=>{
    var fileUrl=path.join(__dirname,"public","index.html");
    response.sendFile(fileUrl);
})
app.post("/home",(request,response)=>{
    var username=request.body.username;
    var chatRoom=request.body.chatRooms;
    console.log("request from login", request.body);
    var temp=querystring.stringify({username:username,chatRoom:chatRoom});
    response.redirect("/chat?"+temp);
})

app.get("/chat",(request,response)=>{
    var fileUrl=path.join(__dirname,"public","chat.html");
    response.sendFile(fileUrl);
})

//when a new user joins the chat
io.on("connection",(socket)=>{
    socket.on("joinRoom",(data)=>{
        socket.join(data.chatRoom);
        console.log(data);
        var obj={username:data.username,message:" has joined the room",chatRoom:data.chatRoom};
        userObj.newUserJoin(socket.id,data.username,data.chatRoom);
        messageObj.postMessage(obj);
        socket.emit("WelcomeUser","Welcome to the Room");
        socket.to(data.chatRoom).broadcast.emit("modifyUserJoinMessage",obj);
        userObj.getAllUsers(data.chatRoom,(userArr)=>{
            var modObj={userArr:userArr,chatRoom:data.chatRoom};
            io.to(data.chatRoom).emit("modifyUsersList",modObj);
        });
        
    })
    socket.on("disconnect",()=>{
        console.log("User has left the room");
        userObj.getUser(socket.id,(tempUser)=>{
            console.log("User to be deleted", tempUser);
            if(tempUser)
            {
                userObj.removeUser(socket.id,(result)=>{
                    if(result)
                    {
                        var obj={username:tempUser.username,message:" has left the room",chatRoom:tempUser.chatRoom};
                        messageObj.postMessage(obj);
                        socket.to(tempUser.chatRoom).broadcast.emit("modifyUserJoinMessage",obj);
                        userObj.getAllUsers(tempUser.chatRoom,(usersArr)=>{
                            var modObj={userArr:usersArr,chatRoom:tempUser.chatRoom};
                            io.to(tempUser.chatRoom).emit("modifyUsersList",modObj);
                        });                        
                    }
                });
            
            }
        });
        
        
    })
    socket.on("message",(obj)=>{
        console.log("message recieved",obj);
        messageObj.postMessage(obj);
        io.to(obj.chatRoom).emit("chatMessage",obj);
        console.log("All Message",messageObj.getAllMessages());
    })
})

server.listen(PORT,(err)=>{
    if(!err)
    {
        console.log(`Server started at PORT ${PORT}`);
    }
})