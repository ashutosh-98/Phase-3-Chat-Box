var mongoClient=require("mongodb").MongoClient;

const users=[];
function newUserJoin(id, username, chatRoom)
{
    var user={id,username,chatRoom};
    mongoClient.connect("mongodb://localhost:27017/",{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            console.log("Error connecting to the server");
        }
        else
        {
            var db=dbHost.db("slDb");
            db.collection("users",(err,coll)=>{
                if(err)
                {
                    console.log("Error connecting to the collection");
                }
                else
                {
                    coll.insertOne(user);
                }
            })

        }
    })
    users.push(user);
}

function getAllUsers(chatRoom,callback)
{
    mongoClient.connect("mongodb://localhost:27017/",{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            console.log("Error connecting to the server");
        }
        else
        {
            var db=dbHost.db("slDb");
            db.collection("users",(err,coll)=>{
                if(err)
                {
                    console.log("Error connecting to the collection");
                }
                else
                {
                    coll.find({chatRoom:chatRoom}).toArray((err, result)=>{
                        if(err)
                        {
                            console.log("Cannot find user");
                        }
                        else
                        {
                            //console.log("DElete using db",result);
                            //var obj={id:result.id,username:result,username,chatRoom:result.chatRoom};
                            return callback(result);
                        }
                    });
                }
            })

        }
    })
    //return callback(null);
}

function getUser(id,callback)
{
    mongoClient.connect("mongodb://localhost:27017/",{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            console.log("Error connecting to the server");
        }
        else
        {
            var db=dbHost.db("slDb");
            db.collection("users",(err,coll)=>{
                if(err)
                {
                    console.log("Error connecting to the collection");
                }
                else
                {
                    coll.findOne({id:id},(err, result)=>{
                        if(err)
                        {
                            console.log("Cannot find user");
                        }
                        else
                        {
                            //console.log("DElete using db",result);
                            //var obj={id:result.id,username:result,username,chatRoom:result.chatRoom};
                            return callback(result);
                        }
                    })
                }
            })

        }
    })
    
}

function removeUser(id,callback)
{
    //var user={id,username,chatRoom};
    mongoClient.connect("mongodb://localhost:27017/",{useUnifiedTopology:true},(err,dbHost)=>{
        if(err)
        {
            console.log("Error connecting to the server");
        }
        else
        {
            var db=dbHost.db("slDb");
            db.collection("users",(err,coll)=>{
                if(err)
                {
                    console.log("Error connecting to the collection");
                }
                else
                {
                    coll.deleteOne({id:id},(err,result)=>{
                        console.log("Delete result",result);
                        if(result.deletedCount==1)
                        {
                            return callback(true);
                        }
                        else    
                            return callback(false);
                    });
                }
            })

        }
    })
}

module.exports={newUserJoin,getAllUsers,getUser,removeUser};