var chatForm=document.getElementById("chatForm");
var chatMessage=document.getElementById("txtChatMessage");
var chatMessagesDiv=document.getElementById("chatMessagesDiv");
var participantsList=document.getElementById("partcipantsList");
//alert("hello");
console.log(Qs.parse(location.search));
var userObject=Qs.parse(location.search,{ignoreQueryPrefix:true});
//var temp="?"+username;
//var username=userObject[temp];
console.log(userObject.username);
var username=userObject.username;
var chatRoom=userObject.chatRoom;
const socket=io();
socket.emit("joinRoom",{username:username,chatRoom:chatRoom});
socket.on("WelcomeUser",(msg)=>{
    chatMessage.innerHTML+=msg;
})
socket.on("chatMessage",(obj)=>{
    formatMesssage(obj);
})

socket.on("modifyUserJoinMessage",(obj)=>{
    var paraElement=document.createElement("p");
    var str=obj.username + " " + obj.message;
    var pTextNode=document.createTextNode(str);
    paraElement.appendChild(pTextNode);
    chatMessagesDiv.appendChild(paraElement);

})

socket.on("modifyUsersList",(obj)=>{
    participantsList.innerHTML="";
    var userArr=obj.userArr;
    var chatRoom=obj.chatRoom;
    for(var i=0;i<userArr.length;i++)
    {
        //console.log(userArr[i].username);
        if(userArr[i].chatRoom==chatRoom)
        {
            var liElement=document.createElement("li");
            var user=userArr[i].username;
            var liTextNode=document.createTextNode(user);
            liElement.appendChild(liTextNode);
            participantsList.appendChild(liElement);
        }
    }
})
function formatMesssage(obj)
{
    var paraElement=document.createElement("p");
    var str=obj.username + " : " + obj.message;
    var pTextNode=document.createTextNode(str);
    paraElement.appendChild(pTextNode);
    chatMessagesDiv.appendChild(paraElement);
    //console.log(str);
    //return str;
}
function sendMessageEventhandler()
{
    socket.emit("message",{message:chatMessage.value,username:username,chatRoom:chatRoom});
    chatMessage.value="";
}